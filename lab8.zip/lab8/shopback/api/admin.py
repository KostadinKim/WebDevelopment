from django.contrib import admin
from api.models import Product,Category

admin.site.register((Category))
admin.site.register((Product))
# Register your models here.