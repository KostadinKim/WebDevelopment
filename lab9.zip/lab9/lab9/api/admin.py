from django.contrib import admin
from api.models import Company, Vacancy

admin.site.register((Vacancy))
admin.site.register((Company))
# Register your models here.