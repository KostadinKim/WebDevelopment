from django.urls import path
from api.views import companies_list, get_company, vacancies_list_by_company, vacancies_list_all, get_vacancy, vacancy_top10

urlpatterns = [
    path('companies', companies_list),
    path('companies/<int:id>/', get_company),
    path('companies/<int:id>/vacancies/', vacancies_list_by_company),
    path('vacancies/', vacancies_list_all),
    path('vacancies/<int:id>/', get_vacancy),
    path('vacancies/top_ten/', vacancy_top10),
]

##/api/companies - List of all Companies
##/api/companies/<int:id>/ - Get one Company
##/api/companies/<int:id>/vacancies/ - List of Vacancies by Company
##/api/vacancies/ - List of all Vacancies
##/api/vacancies/<int:id>/ - Get one Vacancy
##/api/vacancies/top_ten/ - List of top 10 vacancies sorted by decreasing salary